import React, { useEffect, useState } from 'react';
import { DollarSign, Check, X, Eye, AlertCircle } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';

interface AdminWithdrawalsPageProps {
  onNavigate: (page: string) => void;
}

interface WithdrawalWithMerchant {
  id: string;
  merchant_id: string;
  amount: number;
  fee: number;
  net_amount: number;
  status: string;
  admin_notes: string | null;
  bank_reference: string | null;
  created_at: string;
  merchant_name: string;
  merchant_email: string;
  bank_name: string;
  account_holder_name: string;
  iban: string;
  account_number: string;
}

export const AdminWithdrawalsPage: React.FC<AdminWithdrawalsPageProps> = ({ onNavigate }) => {
  const { profile } = useAuth();
  const [loading, setLoading] = useState(true);
  const [requests, setRequests] = useState<WithdrawalWithMerchant[]>([]);
  const [selectedRequest, setSelectedRequest] = useState<WithdrawalWithMerchant | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [bankReference, setBankReference] = useState('');
  const [adminNotes, setAdminNotes] = useState('');
  const [filter, setFilter] = useState<string>('all');

  useEffect(() => {
    if (profile && (profile.role === 'admin' || profile.role === 'superadmin')) {
      loadRequests();
    }
  }, [profile]);

  const loadRequests = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('withdrawal_requests')
        .select(`
          *,
          users_profile!withdrawal_requests_merchant_id_fkey (
            name,
            email
          ),
          merchant_bank_details!merchant_bank_details_merchant_id_fkey (
            bank_name,
            account_holder_name,
            iban,
            account_number
          )
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;

      const formatted = data.map((item: any) => ({
        id: item.id,
        merchant_id: item.merchant_id,
        amount: item.amount,
        fee: item.fee,
        net_amount: item.net_amount,
        status: item.status,
        admin_notes: item.admin_notes,
        bank_reference: item.bank_reference,
        created_at: item.created_at,
        merchant_name: item.users_profile?.name || 'غير معروف',
        merchant_email: item.users_profile?.email || '',
        bank_name: item.merchant_bank_details?.bank_name || '',
        account_holder_name: item.merchant_bank_details?.account_holder_name || '',
        iban: item.merchant_bank_details?.iban || '',
        account_number: item.merchant_bank_details?.account_number || '',
      }));

      setRequests(formatted);
    } catch (err: any) {
      console.error('Load error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async () => {
    if (!selectedRequest) return;
    setProcessing(true);

    try {
      const { error } = await supabase
        .from('withdrawal_requests')
        .update({
          status: 'approved',
          admin_notes: adminNotes || null,
        })
        .eq('id', selectedRequest.id);

      if (error) throw error;

      alert('تمت الموافقة على الطلب بنجاح');
      setShowModal(false);
      setSelectedRequest(null);
      setBankReference('');
      setAdminNotes('');
      await loadRequests();
    } catch (err: any) {
      alert('فشل: ' + err.message);
    } finally {
      setProcessing(false);
    }
  };

  const handleComplete = async () => {
    if (!selectedRequest || !bankReference) {
      alert('يرجى إدخال المرجع البنكي');
      return;
    }
    setProcessing(true);

    try {
      const { error } = await supabase
        .from('withdrawal_requests')
        .update({
          status: 'completed',
          bank_reference: bankReference,
          admin_notes: adminNotes || null,
          processed_at: new Date().toISOString(),
        })
        .eq('id', selectedRequest.id);

      if (error) throw error;

      alert('تم تأكيد التحويل بنجاح');
      setShowModal(false);
      setSelectedRequest(null);
      setBankReference('');
      setAdminNotes('');
      await loadRequests();
    } catch (err: any) {
      alert('فشل: ' + err.message);
    } finally {
      setProcessing(false);
    }
  };

  const handleReject = async () => {
    if (!selectedRequest) return;
    if (!adminNotes) {
      alert('يرجى إضافة سبب الرفض');
      return;
    }
    setProcessing(true);

    try {
      const { error } = await supabase
        .from('withdrawal_requests')
        .update({
          status: 'rejected',
          admin_notes: adminNotes,
          processed_at: new Date().toISOString(),
        })
        .eq('id', selectedRequest.id);

      if (error) throw error;

      alert('تم رفض الطلب');
      setShowModal(false);
      setSelectedRequest(null);
      setAdminNotes('');
      await loadRequests();
    } catch (err: any) {
      alert('فشل: ' + err.message);
    } finally {
      setProcessing(false);
    }
  };

  const openModal = (request: WithdrawalWithMerchant) => {
    setSelectedRequest(request);
    setBankReference('');
    setAdminNotes(request.admin_notes || '');
    setShowModal(true);
  };

  const filteredRequests = requests.filter((r) => {
    if (filter === 'all') return true;
    return r.status === filter;
  });

  if (profile?.role !== 'admin' && profile?.role !== 'superadmin') {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="bg-white rounded-xl p-8 shadow-sm text-center max-w-md">
          <AlertCircle className="w-16 h-16 text-red-600 mx-auto mb-4" />
          <h3 className="text-xl font-bold text-gray-900 mb-2">غير مصرح</h3>
          <p className="text-gray-600 mb-6">هذه الصفحة متاحة للمشرفين فقط</p>
          <button
            onClick={() => onNavigate('home')}
            className="px-6 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700"
          >
            العودة للرئيسية
          </button>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-orange-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">جاري التحميل...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-2">
            <DollarSign className="w-8 h-8 text-orange-500" />
            إدارة طلبات السحب
          </h1>
          <p className="text-gray-600 mt-2">إدارة جميع طلبات سحب التجار</p>
        </div>

        <div className="mb-6 flex gap-2">
          <button
            onClick={() => setFilter('all')}
            className={`px-4 py-2 rounded-lg font-medium ${
              filter === 'all' ? 'bg-orange-500 text-white' : 'bg-white text-gray-700'
            }`}
          >
            الكل ({requests.length})
          </button>
          <button
            onClick={() => setFilter('pending')}
            className={`px-4 py-2 rounded-lg font-medium ${
              filter === 'pending' ? 'bg-orange-500 text-white' : 'bg-white text-gray-700'
            }`}
          >
            قيد المراجعة ({requests.filter((r) => r.status === 'pending').length})
          </button>
          <button
            onClick={() => setFilter('approved')}
            className={`px-4 py-2 rounded-lg font-medium ${
              filter === 'approved' ? 'bg-orange-500 text-white' : 'bg-white text-gray-700'
            }`}
          >
            معتمدة ({requests.filter((r) => r.status === 'approved').length})
          </button>
          <button
            onClick={() => setFilter('completed')}
            className={`px-4 py-2 rounded-lg font-medium ${
              filter === 'completed' ? 'bg-orange-500 text-white' : 'bg-white text-gray-700'
            }`}
          >
            مكتملة ({requests.filter((r) => r.status === 'completed').length})
          </button>
        </div>

        <div className="bg-white rounded-xl shadow-sm overflow-hidden">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">التاجر</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">المبلغ</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">الصافي</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">الحالة</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">التاريخ</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">الإجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {filteredRequests.map((request) => (
                <tr key={request.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4">
                    <div>
                      <div className="text-sm font-medium text-gray-900">{request.merchant_name}</div>
                      <div className="text-sm text-gray-500">{request.merchant_email}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-sm font-medium text-gray-900">
                      {request.amount.toFixed(2)} ريال
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-sm font-bold text-green-600">
                      {request.net_amount.toFixed(2)} ريال
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-semibold ${
                        request.status === 'pending'
                          ? 'bg-yellow-100 text-yellow-700'
                          : request.status === 'approved'
                          ? 'bg-blue-100 text-blue-700'
                          : request.status === 'completed'
                          ? 'bg-green-100 text-green-700'
                          : 'bg-red-100 text-red-700'
                      }`}
                    >
                      {request.status === 'pending' && 'قيد المراجعة'}
                      {request.status === 'approved' && 'معتمدة'}
                      {request.status === 'completed' && 'مكتملة'}
                      {request.status === 'rejected' && 'مرفوضة'}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-sm text-gray-600">
                      {new Date(request.created_at).toLocaleDateString('ar-SA')}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <button
                      onClick={() => openModal(request)}
                      className="text-blue-600 hover:text-blue-800 font-medium text-sm flex items-center gap-1"
                    >
                      <Eye className="w-4 h-4" />
                      عرض التفاصيل
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {showModal && selectedRequest && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">تفاصيل طلب السحب</h2>

              <div className="space-y-4 mb-6">
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h3 className="font-bold text-gray-900 mb-2">معلومات التاجر</h3>
                  <p className="text-sm text-gray-600">الاسم: {selectedRequest.merchant_name}</p>
                  <p className="text-sm text-gray-600">البريد: {selectedRequest.merchant_email}</p>
                </div>

                <div className="bg-gray-50 p-4 rounded-lg">
                  <h3 className="font-bold text-gray-900 mb-2">معلومات الحساب البنكي</h3>
                  <p className="text-sm text-gray-600">البنك: {selectedRequest.bank_name}</p>
                  <p className="text-sm text-gray-600">صاحب الحساب: {selectedRequest.account_holder_name}</p>
                  <p className="text-sm text-gray-600">IBAN: {selectedRequest.iban}</p>
                  {selectedRequest.account_number && (
                    <p className="text-sm text-gray-600">رقم الحساب: {selectedRequest.account_number}</p>
                  )}
                </div>

                <div className="bg-gray-50 p-4 rounded-lg">
                  <h3 className="font-bold text-gray-900 mb-2">معلومات المبلغ</h3>
                  <p className="text-sm text-gray-600">المبلغ الإجمالي: {selectedRequest.amount.toFixed(2)} ريال</p>
                  <p className="text-sm text-gray-600">الرسوم: {selectedRequest.fee.toFixed(2)} ريال</p>
                  <p className="text-sm font-bold text-green-600">الصافي: {selectedRequest.net_amount.toFixed(2)} ريال</p>
                </div>

                {selectedRequest.status === 'pending' && (
                  <>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">ملاحظات الإدارة</label>
                      <textarea
                        value={adminNotes}
                        onChange={(e) => setAdminNotes(e.target.value)}
                        className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500"
                        rows={3}
                        placeholder="أضف ملاحظات (اختياري)"
                      />
                    </div>
                  </>
                )}

                {selectedRequest.status === 'approved' && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      المرجع البنكي <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      value={bankReference}
                      onChange={(e) => setBankReference(e.target.value)}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500"
                      placeholder="أدخل رقم المرجع البنكي"
                    />
                  </div>
                )}
              </div>

              <div className="flex gap-3">
                {selectedRequest.status === 'pending' && (
                  <>
                    <button
                      onClick={handleApprove}
                      disabled={processing}
                      className="flex-1 bg-green-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-green-700 disabled:bg-gray-300 flex items-center justify-center gap-2"
                    >
                      <Check className="w-5 h-5" />
                      الموافقة
                    </button>
                    <button
                      onClick={handleReject}
                      disabled={processing}
                      className="flex-1 bg-red-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-red-700 disabled:bg-gray-300 flex items-center justify-center gap-2"
                    >
                      <X className="w-5 h-5" />
                      رفض
                    </button>
                  </>
                )}

                {selectedRequest.status === 'approved' && (
                  <button
                    onClick={handleComplete}
                    disabled={processing}
                    className="flex-1 bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 disabled:bg-gray-300 flex items-center justify-center gap-2"
                  >
                    <Check className="w-5 h-5" />
                    تأكيد التحويل
                  </button>
                )}

                <button
                  onClick={() => setShowModal(false)}
                  className="flex-1 bg-gray-200 text-gray-700 px-6 py-3 rounded-lg font-semibold hover:bg-gray-300"
                >
                  إغلاق
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
