import React, { useEffect, useState } from 'react';
import { Building2, Save, CheckCircle, AlertCircle, DollarSign } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';

interface BankAccountPageProps {
  onNavigate: (page: string) => void;
}

export const BankAccountPage: React.FC<BankAccountPageProps> = ({ onNavigate }) => {
  const { profile } = useAuth();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [wallet, setWallet] = useState<any>(null);

  const [bankDetails, setBankDetails] = useState({
    bank_name: '',
    account_holder_name: '',
    iban: '',
    account_number: '',
  });

  useEffect(() => {
    if (profile) {
      loadData();
    }
  }, [profile]);

  const loadData = async () => {
    try {
      setLoading(true);

      const [bankRes, walletRes] = await Promise.all([
        supabase
          .from('merchant_bank_details')
          .select('*')
          .eq('merchant_id', profile!.id)
          .maybeSingle(),
        supabase
          .from('merchant_wallets')
          .select('*')
          .eq('merchant_id', profile!.id)
          .maybeSingle(),
      ]);

      if (bankRes.data) {
        setBankDetails({
          bank_name: bankRes.data.bank_name || '',
          account_holder_name: bankRes.data.account_holder_name || '',
          iban: bankRes.data.iban || '',
          account_number: bankRes.data.account_number || '',
        });
      }

      setWallet(walletRes.data);
    } catch (err: any) {
      console.error('Load error:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    setMessage(null);

    try {
      if (!bankDetails.bank_name || !bankDetails.account_holder_name || !bankDetails.iban) {
        throw new Error('يرجى ملء جميع الحقول المطلوبة');
      }

      const { data: existing } = await supabase
        .from('merchant_bank_details')
        .select('merchant_id')
        .eq('merchant_id', profile!.id)
        .maybeSingle();

      if (existing) {
        const { error } = await supabase
          .from('merchant_bank_details')
          .update({
            ...bankDetails,
            updated_at: new Date().toISOString(),
          })
          .eq('merchant_id', profile!.id);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('merchant_bank_details')
          .insert({
            merchant_id: profile!.id,
            ...bankDetails,
          });

        if (error) throw error;
      }

      setMessage({ type: 'success', text: 'تم حفظ بيانات الحساب البنكي بنجاح' });
      setTimeout(() => setMessage(null), 3000);
    } catch (err: any) {
      console.error('Save error:', err);
      setMessage({ type: 'error', text: err.message || 'فشل الحفظ' });
    } finally {
      setSaving(false);
    }
  };

  const handleRequestWithdrawal = async () => {
    if (!window.confirm('هل أنت متأكد من طلب سحب الرصيد؟')) return;

    try {
      const { data: bankCheck } = await supabase
        .from('merchant_bank_details')
        .select('*')
        .eq('merchant_id', profile!.id)
        .maybeSingle();

      if (!bankCheck) {
        throw new Error('يرجى إضافة بيانات الحساب البنكي أولاً');
      }

      if (!bankCheck.is_verified) {
        throw new Error('بيانات الحساب البنكي لم يتم التحقق منها بعد');
      }

      if (!wallet || wallet.balance <= 0) {
        throw new Error('لا يوجد رصيد كافٍ للسحب');
      }

      const fee = 0;
      const netAmount = wallet.balance - fee;

      const { error } = await supabase
        .from('withdrawal_requests')
        .insert({
          merchant_id: profile!.id,
          amount: wallet.balance,
          fee: fee,
          net_amount: netAmount,
          status: 'pending',
        });

      if (error) throw error;

      setMessage({ type: 'success', text: 'تم إرسال طلب السحب بنجاح' });
      onNavigate('withdrawal-requests');
    } catch (err: any) {
      setMessage({ type: 'error', text: err.message });
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-orange-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">جاري التحميل...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-3xl mx-auto px-4">
        <div className="mb-6">
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-2">
            <Building2 className="w-8 h-8 text-orange-500" />
            بيانات الحساب البنكي
          </h1>
          <p className="text-gray-600 mt-2">أدخل بيانات حسابك البنكي لاستلام الأرباح</p>
        </div>

        {message && (
          <div
            className={`mb-6 p-4 rounded-lg flex items-center gap-3 ${
              message.type === 'success'
                ? 'bg-green-50 border border-green-200'
                : 'bg-red-50 border border-red-200'
            }`}
          >
            {message.type === 'success' ? (
              <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
            ) : (
              <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0" />
            )}
            <p className={message.type === 'success' ? 'text-green-700' : 'text-red-700'}>
              {message.text}
            </p>
          </div>
        )}

        {wallet && (
          <div className="bg-gradient-to-r from-green-600 to-teal-600 rounded-lg p-6 mb-6 text-white">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-100 mb-1">رصيدك الحالي</p>
                <p className="text-3xl font-bold">{wallet.balance.toFixed(2)} ريال</p>
              </div>
              <DollarSign className="w-12 h-12 text-green-200" />
            </div>
          </div>
        )}

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-6">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                اسم البنك <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={bankDetails.bank_name}
                onChange={(e) => setBankDetails({ ...bankDetails, bank_name: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500"
                placeholder="مثال: البنك الأهلي السعودي"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                اسم صاحب الحساب <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={bankDetails.account_holder_name}
                onChange={(e) => setBankDetails({ ...bankDetails, account_holder_name: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500"
                placeholder="الاسم الكامل كما في السجل البنكي"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                رقم الآيبان (IBAN) <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={bankDetails.iban}
                onChange={(e) => setBankDetails({ ...bankDetails, iban: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500"
                placeholder="SA0000000000000000000000"
                dir="ltr"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                رقم الحساب البنكي
              </label>
              <input
                type="text"
                value={bankDetails.account_number}
                onChange={(e) => setBankDetails({ ...bankDetails, account_number: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500"
                placeholder="رقم الحساب"
                dir="ltr"
              />
            </div>

            <button
              onClick={handleSave}
              disabled={saving}
              className="w-full bg-orange-500 text-white px-6 py-3 rounded-lg font-semibold hover:bg-orange-600 disabled:bg-gray-300 flex items-center justify-center gap-2"
            >
              <Save className="w-5 h-5" />
              {saving ? 'جاري الحفظ...' : 'حفظ'}
            </button>
          </div>
        </div>

        {wallet && wallet.balance > 0 && (
          <button
            onClick={handleRequestWithdrawal}
            className="w-full bg-green-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-green-700 flex items-center justify-center gap-2"
          >
            <DollarSign className="w-5 h-5" />
            طلب سحب الرصيد
          </button>
        )}
      </div>
    </div>
  );
};
